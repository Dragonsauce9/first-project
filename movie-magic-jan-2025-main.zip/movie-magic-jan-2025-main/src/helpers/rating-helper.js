export default function showRatingHelper(rating) {
    return '★'.repeat(Math.trunc(rating));
}
